import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Yeni kimlik doğrulama ile ilgili import'lar
import Login from './components/Login';
import MainLayout from './components/MainLayout';

// Tema CSS'i ve özel CSS'i import et
import '../brite.min.css';
import './App.css'; 

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

const App = () => {
    // Giriş durumunu tutan state
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    // Yükleme durumunu tutan yeni state (cookie kontrolü için)
    const [isLoading, setIsLoading] = useState(true);

    // Uygulama ilk yüklendiğinde backend'e oturum kontrolü isteği gönder
    useEffect(() => {
        const checkAuthStatus = async () => {
            try {
                // Backend'e basit bir oturum kontrolü isteği göndereceğiz.
                // Backend, eğer geçerli bir auth-token cookie varsa başarılı yanıt dönecek.
                // Bu örnek için backend'de '/api/auth/checkSession' adında yeni bir rota tanımlamamız gerekecek.
                // Şimdilik, sadece backend'den yanıt alıp almadığımıza bakabiliriz.
                // Veya şimdilik, varsayılan olarak kullanıcıyı logout kabul edip, sadece login ile durumu değiştirebiliriz.
                // Daha güçlü bir kontrol için backend'e yeni bir rota (örneğin /api/auth/status) eklemeliyiz.
                // Geçici olarak, sadece varsayılan olarak logout kabul edip login olduğunda set ediyoruz.
                // Eğer otomatik login istiyorsak, backend'de session kontrolü zorunludur.

                // Bu kısım, sayfa yenilendiğinde otomatik oturum açma için backend'e istek göndermelidir.
                // Eğer backend'de '/api/auth/status' gibi bir rota varsa:
                // const response = await fetch('http://localhost:3000/api/auth/status');
                // if (response.ok) {
                //     setIsLoggedIn(true);
                // } else {
                //     setIsLoggedIn(false);
                // }

                // Şimdilik, cookie mekanizmasının doğru çalıştığını varsayıp sadece isLoading'i false yapalım.
                // Eğer kullanıcı giriş yapmışsa, login işlemi zaten isLoggedIn'i true yapmıştır.
                // Sayfa yenilendiğinde tarayıcı cookie'yi otomatik gönderir ve başarılı login'de yönlendirme yapılır.
                // Ancak bu, sayfa yüklendiğinde otomatik olarak "giriş yapılmış" demek için yeterli değil.
                // Backend'de gerçekten bir token doğrulama rotası olmalı.
                
                // Güvenli bir yöntem: Backend'de token doğrulama uç noktası olmalı
                const response = await fetch(`${API_BASE_URL}/api/auth/verify`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    // credentials: 'include' HTTP-only cookie'lerin gönderilmesi için önemlidir.
                    credentials: 'include' 
                });

                if (response.ok) {
                    setIsLoggedIn(true);
                } else {
                    setIsLoggedIn(false);
                }

            } catch (error) {
                console.error('Oturum kontrol hatası:', error);
                setIsLoggedIn(false); // Hata durumunda da çıkış yapmış kabul et
            } finally {
                setIsLoading(false); // Kontrol bittikten sonra yükleniyor durumunu false yap
            }
        };

        checkAuthStatus();
    }, []); // Bağımlılık dizisi boş olduğu için sadece bir kez çalışır

    // Giriş işlemini yöneten fonksiyon (token artık frontend'e gelmiyor)
    const handleLogin = () => {
        setIsLoggedIn(true);
        // navigate('/') Login.jsx'te yapıldığı için burada tekrar etmiyoruz.
    };

    // Çıkış işlemini yöneten fonksiyon
    const handleLogout = async () => {
        try {
            // Backend'e çıkış isteği gönder (cookie'yi temizlemek için)
            await fetch(`${API_BASE_URL}/api/auth/logout`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include' // Cookie'yi göndermek için
            });
            setIsLoggedIn(false);
            // Çıkış yaptıktan sonra login sayfasına yönlendir
            window.location.href = '/login'; // navigate yerine window.location.href kullanıldı
        } catch (error) {
            console.error('Çıkış hatası:', error);
            // Kullanıcıya hata mesajı gösterebilirsin
        }
    };

    // Eğer yükleme devam ediyorsa, bir yükleniyor ekranı göster
    if (isLoading) {
        return <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>Yükleniyor...</div>;
    }

    return (
        <Router>
            <Routes>
                {/* Giriş Sayfası Rotası */}
                <Route path="/login" element={<Login handleLogin={handleLogin} />} />

                {/* Ana Uygulama Rotası (Korunan Rota) */}
                <Route
                    path="/*"
                    element={isLoggedIn ? (
                        <MainLayout handleLogout={handleLogout} />
                    ) : (
                        <Navigate to="/login" />
                    )}
                />
            </Routes>
        </Router>
    );
};

export default App;