const bcrypt = require('bcrypt');

const password = '19421942k';
const saltRounds = 10; // Güvenli bir hash için ideal sayı

bcrypt.hash(password, saltRounds, function(err, hash) {
    if (err) {
        console.error(err);
    } else {
        console.log(hash); // Bu hash'i kopyala
    }
});